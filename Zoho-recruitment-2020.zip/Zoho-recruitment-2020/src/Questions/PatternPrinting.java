package Questions;

import java.util.*;

public class PatternPrinting {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		try {
			int input = in.nextInt();
			for (int i = input; i > 0; i--) 
			{ 
			    for (int j = input; j > i; j--) 
			        System.out.print(j); 
			 
			    for (int j = i; j > 0; j--) 
			        System.out.print(i); 
			 
			    System.out.println(); 
			
		}
	} 
	finally {
		in.close();
	}

	}

}
